with open("flag.txt") as file:
    flag = file.read().strip()
functionEncrypt = lambda x: chr(ord(char)^1+2020>>3)
newFlag = "".join([functionEncrypt(char) for char in flag])
newFlag = newFlag.encode('hex')
with open("flag.en", "wb") as file:
    file.write(newFlag)
