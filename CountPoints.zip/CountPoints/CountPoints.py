# -*- coding: utf-8 -*-
import base64
import string
import json
import SocketServer
import threading
import random
from fractions import gcd
data = '''Cho hình tam giác OAB. A(a,0) thuộc Ox, B(0,b) thuộc Oy. Hỏi có tất cả bao nhiêu điểm, mà toạ độ của nó là số nguyên, nằm trong hoặc nằm trên tam giác OAB?
Điều kiện: 10^6 < a,b <10^7
Ví dụ: A(2,0) và B(0,3) thì số điểm là 7 gồm các điểm (1,0) (2,0) (0,0) (0,1) (0,2) (0,3) (1,1)
Khi ban tra loi dung 100 cau thi flag se xuat hien!
'''
data2 = '''Cho a={x} và b={y} . So diem thoa man: '''
flag = "MSEC{L3t_l34rn_4l90r1thm}"



class ThreadedTCPServer(SocketServer.ThreadingMixIn, SocketServer.TCPServer):
    allow_reuse_address = True

class ThreadedTCPRequestHandler(SocketServer.BaseRequestHandler):
    def init(self):
        pass
	def __gcd(a, b):
	    if(b != 0):
	       	return __gcd(b, a % b)
	    else:
	        return a
    def handle(self):
    	check = True
    	self.request.settimeout(300)
    	rsend = self.request.sendall
    	rclose = self.request.close
    	rrecv = self.request.recv
	rsend(data)
	for i in range(1,11):
	    	a = random.randint(1, i)
	    	b = random.randint(1, i)
	    	rsend(data2.format(x=a,y=b))

	    	tren = int(a + b + gcd(a,b))
	    	trong = (a * b - tren)/ 2 + 1
	    	tong = tren+trong
	    	x = rrecv(4096).rstrip('\n').rstrip('\r')
	    	x= int(x)

	    	if x == tong:
	    		rsend("OK! Next\n")
	    	else:
			check = False
	    		rsend("Chuc ban may man lan sau!\n")
			rclose()
	for i in range(90):
	    	a = random.randint(1, 1000000000)
	    	b = random.randint(1, 1000000000)
	    	rsend(data2.format(x=a,y=b))

	    	tren = int(a + b + gcd(a,b))
	    	trong = (a * b - tren)/ 2 + 1
	    	tong = tren+trong
	    	x = rrecv(4096).rstrip('\n').rstrip('\r')
	    	x= int(x)

	    	if x == tong:
	    		rsend("OK! Next\n")
	    	else:
			check = False
	    		rsend("Chuc ban may man lan sau!\n")
			rclose()
    	if check == True:
    		rsend("\nFlag = " + flag)
    	rclose()




HOST, PORT = '0.0.0.0', 1337
while True:
    server = ThreadedTCPServer((HOST, PORT), ThreadedTCPRequestHandler)
    server_thread = threading.Thread(target=server.serve_forever)
    server_thread.daemon = True
    server_thread.start()
    print "Server loop running in thread:", server_thread.name
    server_thread.join()
