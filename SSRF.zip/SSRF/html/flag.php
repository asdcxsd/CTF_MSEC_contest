<?php
  $flag = 'MSEC{ssrf_and_parse_url_is_very_interting}'
?>
