<?php
require("library.php");

if (isset($_GET["page"]))
  echo make_a_request(urldecode($_GET["page"]));
else
{
  if (isset($_GET["read"]))
  {
    if ($_SERVER['REMOTE_ADDR'] !== '127.0.0.1')
      die("Your IP address can't read file!!");

    $filename = $_GET["read"];
    if(in_array($filename, $allowedPages) && file_exists($filename)){
      echo "Path: ".realpath($filename). "</br>";
      echo "Content: </br>";
      highlight_file($filename);

    }
    else{
      die("File don't exist or File isn't in access array !!");
    }
  }
  else
    highlight_file(__FILE__);
}
#flag in: flag.php
?>
