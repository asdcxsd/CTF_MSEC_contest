# -*- coding: utf-8 -*-
import base64
import string
import json
import SocketServer
import threading
import random,math
data0 = '''Happy new year!!\n\n'''
flag = 'MSEC{the_ants_are_very_funny}'
class ThreadedTCPServer(SocketServer.ThreadingMixIn, SocketServer.TCPServer):
    allow_reuse_address = True

class ThreadedTCPRequestHandler(SocketServer.BaseRequestHandler):
    def init(self):
        pass

    def handle(self):
        self.request.settimeout(30)
        rsend = self.request.sendall
        rclose = self.request.close
        rrecv = self.request.recv

        rsend(data0);
        N = random.randint(1, 100)
        M = random.randint(1, 100)
        c = []
        for i in range(M):
            c.append(str(random.randint(-N, N)));
        data = "{} {}\n{}\nNhap ket qua:".format(str(N), str(M), " ".join(c))

        rsend(data);
        ans = 0
        for i in c:
            so = int(i)
            if (so < 0):
                ans = max(ans, -so)
            else:
                ans = max(ans, N-so)
        x = rrecv(4096).rstrip('\n').rstrip('\r')
        try:
            if (int(x) == ans):
                rsend(flag)
            else:
                rsend("Game Over!")
        except:
            rsend("Game Over!")
        rclose()


HOST, PORT = '0.0.0.0', 1337
while True:
    server = ThreadedTCPServer((HOST, PORT), ThreadedTCPRequestHandler)
    server_thread = threading.Thread(target=server.serve_forever)
    server_thread.daemon = True
    server_thread.start()
    print "Server loop running in thread:", server_thread.name
    server_thread.join()
