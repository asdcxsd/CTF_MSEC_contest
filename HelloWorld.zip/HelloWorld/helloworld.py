# -*- coding: utf-8 -*-
import base64
import string
import json
import SocketServer
import threading
import random
data = '''Hello World!! You can send "Hello World!" for me??
'''

class ThreadedTCPServer(SocketServer.ThreadingMixIn, SocketServer.TCPServer):
    allow_reuse_address = True

class ThreadedTCPRequestHandler(SocketServer.BaseRequestHandler):
    def init(self):
        pass

    def handle(self):
        self.request.settimeout(300)
        rsend = self.request.sendall
        rclose = self.request.close
        rrecv = self.request.recv

        rsend(data);

        x = rrecv(4096).rstrip('\n').rstrip('\r')
        if (x == "Hello World!") :
            rsend("MSEC{h3ll0_w0rld!!!}");
        else:
            rsend("Sorry!! I think You will win");
        rclose()

HOST, PORT = '0.0.0.0', 1337
while True:
    server = ThreadedTCPServer((HOST, PORT), ThreadedTCPRequestHandler)
    server_thread = threading.Thread(target=server.serve_forever)
    server_thread.daemon = True
    server_thread.start()
    print "Server loop running in thread:", server_thread.name
    server_thread.join()
