import socket
from time import*

HOST = "127.0.0.1"
PORT = 1337

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

server.connect((HOST, PORT))
sleep(1)

for i in range(0,1000):
	
	txt = repr(server.recv(2048))
	print txt
	if 'MSEC' in txt:
		break
	if 'OK' in txt:
		continue
	#x = txt.splitlines()
	x=txt.replace("'","").split("=")
	print(x)
	b=x[2].split(">>>")
	b=int(b[0])
	y=x[1].split(" ")
	a=int(y[0])
	server.sendall(str(a+b))

sleep(1)
data = repr(server.recv(2048))
print data