# -*- coding: utf-8 -*-
import base64
import string
import json
import SocketServer
import threading
import random
data = '''Cho 100 cặp số nguyên ngẫu nhiên (a,b). 
Người chơi phải nhập tổng a + b lần lượt cho từng cặp số đã cho. 
Sai ở bất kì cặp số nào, trò chơi lập tức kết thúc. 
Nếu nhập đúng 100 lần tổng a+b thì XIN CHÚC MỪNG, bạn là người chiến thắng!
'''
flag = 'MSEC{add_more_efforts_to_get_more_points}'
class ThreadedTCPServer(SocketServer.ThreadingMixIn, SocketServer.TCPServer):
    allow_reuse_address = True

class ThreadedTCPRequestHandler(SocketServer.BaseRequestHandler):
    def init(self):
        pass

    def handle(self):
        self.request.settimeout(30)
        rsend = self.request.sendall
        rclose = self.request.close
        rrecv = self.request.recv

        rsend(data);

        for i in range(100):
            a = random.randint(1, 100000)
            b = random.randint(1, 99999)
            rsend("a" + str(i+1) +  "=" + str(a) + " " + "b" + str(i+1) +  "=" + str(b) + "\n")
            rsend("Nhap a + b = ")
            x = rrecv(4096).rstrip('\n').rstrip('\r')
            x= int(x)
            if x == (a+b):
                rsend("OK\n")
                if i == 100:
                    rsend(flag)                
            else:
                rsend("Game over!\n")
                break
        rclose()


HOST, PORT = '0.0.0.0', 1337
while True:
    server = ThreadedTCPServer((HOST, PORT), ThreadedTCPRequestHandler)
    server_thread = threading.Thread(target=server.serve_forever)
    server_thread.daemon = True
    server_thread.start()
    print "Server loop running in thread:", server_thread.name
    server_thread.join()
